# Production Screenshots

Base URL: https://automaspec.vercel.app

- prod-home-desktop.png -> https://automaspec.vercel.app/
- prod-login-desktop.png -> https://automaspec.vercel.app/login
- prod-choose-organization-desktop.png -> https://automaspec.vercel.app/choose-organization
- prod-dashboard-desktop.png -> https://automaspec.vercel.app/dashboard
- prod-analytics-desktop.png -> https://automaspec.vercel.app/analytics
- prod-rpc-docs-desktop.png -> https://automaspec.vercel.app/rpc/docs

## Folder Views

- prod-folder-components-desktop.png -> Folder: Components
- prod-folder-database-desktop.png -> Folder: Database
- prod-home-tablet.png -> https://automaspec.vercel.app/
- prod-login-tablet.png -> https://automaspec.vercel.app/login
- prod-choose-organization-tablet.png -> https://automaspec.vercel.app/choose-organization
- prod-dashboard-tablet.png -> https://automaspec.vercel.app/dashboard
- prod-analytics-tablet.png -> https://automaspec.vercel.app/analytics
- prod-rpc-docs-tablet.png -> https://automaspec.vercel.app/rpc/docs

## Folder Views

- prod-folder-components-tablet.png -> Folder: Components
- prod-folder-database-tablet.png -> Folder: Database
- prod-home-mobile.png -> https://automaspec.vercel.app/
- prod-login-mobile.png -> https://automaspec.vercel.app/login
- prod-choose-organization-mobile.png -> https://automaspec.vercel.app/choose-organization
- prod-dashboard-mobile.png -> https://automaspec.vercel.app/dashboard
- prod-analytics-mobile.png -> https://automaspec.vercel.app/analytics
- prod-rpc-docs-mobile.png -> https://automaspec.vercel.app/rpc/docs

## Folder Views

- prod-folder-components-mobile.png -> Folder: Components
- prod-folder-database-mobile.png -> Folder: Database
