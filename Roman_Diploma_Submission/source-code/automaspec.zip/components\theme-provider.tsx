'use client'

import type { ComponentProps } from 'react'

import { SpacemanThemeProvider } from '@space-man/react-theme-animation'
import { ThemeProvider as NextThemesProvider } from 'next-themes'

export function ThemeProvider({ children, ...props }: ComponentProps<typeof NextThemesProvider>) {
    return (
        <NextThemesProvider {...props} attribute="class">
            <SpacemanThemeProvider
                themes={['light', 'dark', 'system']}
                defaultTheme="system"
                defaultColorTheme="default"
            >
                {children}
            </SpacemanThemeProvider>
        </NextThemesProvider>
    )
}
