import { oc } from '@orpc/contract'
import * as z from 'zod'

import { memberSelectSchema } from '@/lib/types'

const exportDataOutput = z.object({
    user: z.object({
        id: z.string(),
        name: z.string(),
        email: z.string(),
        image: z.string().nullish(),
        createdAt: z.string()
    }),
    memberships: z.array(
        z.object({
            organizationId: z.string(),
            organizationName: z.string(),
            role: z.enum(['owner', 'admin', 'member']).nullable()
        })
    )
})

const exportAccountContract = oc
    .route({
        method: 'GET',
        path: '/account/{userId}',
        tags: ['account'],
        summary: 'Export account data',
        description: 'Export the current user account data (profile + memberships)'
    })
    .input(memberSelectSchema.pick({ userId: true }))
    .output(exportDataOutput)

const deleteAccountContract = oc
    .route({
        method: 'DELETE',
        path: '/account/{userId}',
        tags: ['account'],
        summary: 'Delete account',
        description: 'Delete the current user account'
    })
    .input(memberSelectSchema.pick({ userId: true }))
    .output(z.object({ success: z.boolean() }))

export const accountContract = {
    account: {
        export: exportAccountContract,
        delete: deleteAccountContract
    }
}
